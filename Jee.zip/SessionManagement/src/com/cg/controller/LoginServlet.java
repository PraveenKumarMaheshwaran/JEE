package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.pojo.LoginProcessor;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		session.setMaxInactiveInterval(20);
		String id=session.getId();
		System.out.println("id=" +id);
		String action=request.getParameter("action");
		if("index".equals(action))
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("login.html");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession();
		System.out.println("Session is new="+session.isNew());
		String action=request.getParameter("action");
		if("login".equals(action))
		{
		String user=request.getParameter("username");
		String pass=request.getParameter("password");
		LoginProcessor obj=new LoginProcessor();
		if(obj.validate(user, pass))
		{
			session.setAttribute("username", user);
			session.setAttribute("password", pass);
			
			response.sendRedirect("DestinationServlet");
		
		}
		else
		{
			response.sendError(406);
		
		}
	}
}

}
