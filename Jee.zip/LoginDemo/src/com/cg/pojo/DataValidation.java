package com.cg.pojo;

public class DataValidation {
	public boolean validate(String user,String pass)
	{
		boolean flag=false;
		if(user.equals("Capgemini")&&pass.equals("123"))
		{
			flag=true;
		}
		return flag;
	}

}
