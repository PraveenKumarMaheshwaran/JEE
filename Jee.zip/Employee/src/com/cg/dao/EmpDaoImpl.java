package com.cg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;






import com.cg.bean.EmpBean;

import com.cg.util.DBUtil;

public class EmpDaoImpl implements EmpDao{
	Connection con;
	public EmpDaoImpl()
	{
		con=DBUtil.getConnect();
	}

	@Override
	public ArrayList<EmpBean> showData() {
		// TODO Auto-generated method stub
		ArrayList<EmpBean> list=new ArrayList<EmpBean>();
		try{
		Statement smt=con.createStatement();
		String sql="Select * from empdetails";
		ResultSet rst=smt.executeQuery(sql);
		while(rst.next())
		{
			EmpBean bean =new EmpBean(rst.getString(1),rst.getString(2),rst.getInt(3));
			list.add(bean);
		}
	}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return list;
	}


	@Override
	public int updateEmp(EmpBean bean) {
		// TODO Auto-generated method stub
		try{
		Statement smt=con.createStatement();
		String sql="update empdetails set salary=?";
		ResultSet rst=smt.executeQuery(sql);
		if(rst.next())
		{
			bean.setSalary(rst.getInt(1));
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return 0;
	}

}
