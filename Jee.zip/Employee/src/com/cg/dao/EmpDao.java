package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.EmpBean;

public interface EmpDao {
	ArrayList<EmpBean> showData();
	public int updateEmp(EmpBean bean);

}
