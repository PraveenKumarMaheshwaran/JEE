package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.EmpBean;
import com.cg.dao.EmpDao;
import com.cg.dao.EmpDaoImpl;

public class EmpServiceImpl implements EmpService{
	EmpDao dao;
	public EmpServiceImpl(){
		dao=new EmpDaoImpl();
	}

	@Override
	public ArrayList<EmpBean> showData() {
		// TODO Auto-generated method stub
		return dao.showData();
	}

	@Override
	public int updateEmp(EmpBean bean) {
		// TODO Auto-generated method stub
		return dao.updateEmp(bean);
	}

	

	

}
