package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.EmpBean;

public interface EmpService {
	ArrayList<EmpBean> showData();
	public int updateEmp(EmpBean bean);

}
