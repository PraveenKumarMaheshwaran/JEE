package com.cg.pojo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.util.DBUtil;

public class LoginProcessor {
	Connection con;
	public LoginProcessor(){
		con=DBUtil.getConnect();
	}
	public boolean validate(String user,String pass)
	{
		boolean flag=false;
		String sql="SELECT * FROM userjee WHERE username=? and password=?";
		try{
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, user);
			pst.setString(2, pass);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				flag=true;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		return flag;
	}
}
