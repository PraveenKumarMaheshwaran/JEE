package com.cg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;




import com.cg.bean.UserBean;
import com.cg.util.DBUtil;

public class UserDaoImpl implements UserDao{
	Connection con;

	public UserDaoImpl(){
		con=DBUtil.getConnect();
	}
	@Override
	public ArrayList<UserBean> showData() {
		// TODO Auto-generated method stub
		ArrayList<UserBean>list=new ArrayList<UserBean>();
		try{
			Statement smt=con.createStatement();
			String sql="select * from userjee";
			ResultSet rst=smt.executeQuery(sql);
			while(rst.next())
			{
				UserBean obj=new UserBean(rst.getString(1),rst.getString(2));
				list.add(obj);
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return list;
	}

}
