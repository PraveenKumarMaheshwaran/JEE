package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.UserBean;

public interface UserDao {
public ArrayList<UserBean> showData(); 
}
