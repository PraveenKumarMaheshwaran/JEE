package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.UserBean;

public interface DataService {
	ArrayList<UserBean> showData();

}
