package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.UserBean;
import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;

public class DataServiceImpl implements DataService{
	UserDao dao;
	public DataServiceImpl(){
		dao=new UserDaoImpl();
	}
	

	@Override
	public ArrayList<UserBean> showData() {
		// TODO Auto-generated method stub
		return dao.showData();
	}

}
