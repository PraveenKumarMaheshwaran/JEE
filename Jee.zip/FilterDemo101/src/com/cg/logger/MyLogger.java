package com.cg.logger;

import java.io.IOException;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class MyLogger {
	static Logger logger=Logger.getLogger(MyLogger.class);
	public static Logger configLogger()
	{
		SimpleLayout layout=new SimpleLayout();
		try{
			FileAppender appender=new FileAppender(layout,"basic.log");
			logger.addAppender(appender);
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return logger;
	}

}
