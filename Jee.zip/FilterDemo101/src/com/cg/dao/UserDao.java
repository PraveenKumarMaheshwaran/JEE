package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.FilterBean;

public interface UserDao {
	ArrayList<FilterBean> showData();
}
