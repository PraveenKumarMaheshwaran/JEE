package com.cg.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.bean.FilterBean;
import com.cg.logger.MyLogger;

/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter(urlPatterns={"*"})
public class LoginFilter implements Filter {
	static Logger logger=MyLogger.configLogger();

    /**
     * Default constructor. 
     */
    public LoginFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req=(HttpServletRequest)request;
		logger.info("Recieved First Request from"+req.getPathInfo());
		HttpSession session=req.getSession(true);
		logger.info("Session is new="+session.isNew());
		logger.info("session id="+session.getId());
		chain.doFilter(request, response);
		ArrayList<FilterBean> list=(ArrayList<FilterBean>) session.getAttribute("data");
		logger.info("data from controller"+list);
		String msg=(String) session.getAttribute("message");
		logger.info("got "+msg);
		if(session.isNew()==false){
		PrintWriter out=((HttpServletResponse)response).getWriter();
		for (FilterBean obj : list)
		{
			out.println(obj.getUsername()+" "+obj.getPassword());
			out.println("<br>");
		}
		logger.info("response sent");
		}
		// pass the request along the filter chain
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
