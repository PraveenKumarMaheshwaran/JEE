package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.FilterBean;

public interface DataService {
	ArrayList<FilterBean> showData();

}
