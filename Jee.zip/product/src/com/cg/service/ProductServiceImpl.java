package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.ProductBean;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {
	ProductDao dao;
	public ProductServiceImpl()
	{
		dao=new ProductDaoImpl();
	}

	@Override
	public ArrayList<ProductBean> showData() {
		// TODO Auto-generated method stub
		return dao.showData();
	}

}
