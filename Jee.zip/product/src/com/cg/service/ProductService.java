package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.ProductBean;

public interface ProductService {
	ArrayList<ProductBean> showData();

}
