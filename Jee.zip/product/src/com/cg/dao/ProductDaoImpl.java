package com.cg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.ProductBean;
import com.cg.util.DBUtil;

public class ProductDaoImpl implements ProductDao {
	Connection con;
	public ProductDaoImpl(){
		con=DBUtil.getConnect();
	}

	@Override
	public ArrayList<ProductBean> showData() {
		// TODO Auto-generated method stub
		ArrayList<ProductBean> list=new ArrayList<ProductBean>();
		try{
		Statement smt=con.createStatement();
		String sql="SELECT * FROM PRODUCT ";
		ResultSet rst=smt.executeQuery(sql);
		while(rst.next())
		{
			ProductBean bean=new ProductBean(rst.getInt(1),rst.getString(2),rst.getInt(3));
			list.add(bean);
		}
		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
		return list;
	}

}
